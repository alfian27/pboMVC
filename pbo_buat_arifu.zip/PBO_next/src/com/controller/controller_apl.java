/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.controller;
import com.view.FormLogin;
import com.view.PermintaanObat;
import com.view.RiwayatPermintaanObat;
import com.view.StokObat;
import com.view.TambahObat;
import com.view.TambahStok;

import java.sql.SQLException;
/**
 *
 * @author Alfian
 */
public interface controller_apl {
    public void simpanPermintaanObat(PermintaanObat po);
    public void menuPermintaanObatTO(TambahObat so);
    public void menuPermintaanObatTS(TambahStok so);
    public void menuPermintaanObatSO(StokObat so);
    public void importfile(TambahObat to);
    public void kembalikeStokObat1(TambahObat so);
    public void kembalikeStokObat(TambahStok to) throws SQLException;
    public void cariStokObat(StokObat so) throws SQLException;
    public void hapusStok(StokObat so) throws SQLException;
    public void tambahStok(StokObat so);
    public void ExportObat(StokObat so) throws SQLException;
    public void cariObatTBL(PermintaanObat po) throws SQLException; 
    public void tampilTabelObat(PermintaanObat po) throws SQLException;
    public void simpanObat(TambahObat to) throws SQLException;
    public void navObat(PermintaanObat po) throws SQLException;
    public void navTambahObat(StokObat so) throws SQLException;
    public void tampilTabelStokObat(StokObat sob) throws SQLException;
    public void tampilKode(TambahObat to) throws SQLException;
    public void TampilDropdown(PermintaanObat pob) throws SQLException;
    public void btnLogin(FormLogin login) throws SQLException;
//    public void btnKembaliPO(RiwayatPermintaanObat ro) throws SQLException;
    public void btnRiwayat(PermintaanObat PO) throws SQLException;
}
