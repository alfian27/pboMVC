/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.model;

import java.util.Random;

import com.controller.controller_apl;
import com.koneksi.koneksi;
import com.view.FormLogin;

import com.view.TambahObat;
import com.view.PermintaanObat;
import com.view.TambahStok;
import com.view.RiwayatPermintaanObat;
import com.view.StokObat;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.PrintWriter;
import java.net.ConnectException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Alfian
 */
public class model_apl implements controller_apl{

    @Override
    public void simpanPermintaanObat(PermintaanObat po){
        Object a = po.combo.getSelectedItem();
        String b = a.toString();
        JOptionPane.showMessageDialog(po, b);
    }
    
    @Override
    public void menuPermintaanObatTO(TambahObat so){
        try {
            PermintaanObat so1 = new PermintaanObat();
            so1.setVisible(true);
            so.dispose();
        } catch (Exception e) {
        }
    }
    
    @Override
    public void menuPermintaanObatTS(TambahStok so){
        try {
            PermintaanObat so1 = new PermintaanObat();
            so1.setVisible(true);
            so.dispose();
        } catch (Exception e) {
        }
    }
    
    @Override
    public void menuPermintaanObatSO(StokObat so){
        try {
            PermintaanObat so1 = new PermintaanObat();
            so1.setVisible(true);
            so.dispose();
        } catch (Exception e) {
        }
    }
    
    @Override
    public void importfile(TambahObat to){
//        String filepath = "C:\\Users\\Alfian\\Desktop\\pbo'" + to.txtFile +"'" ;
//        
        try {
            FileReader fr = new FileReader("C:\\Users\\Alfian\\Desktop\\pbo\\" + to.txtFile.getText());
            BufferedReader br = new BufferedReader(fr);

            Object [] tableLines = br.lines().toArray();
            for (int i = 0; i <tableLines.length; i++) {
                String line = tableLines[i].toString().trim();
                
                String [] datarow = line.split("/");
                to.inputNamaObat.setText(datarow[0]);
                to.inputJenisObat.setText(datarow[1]);
                to.inputSatuanObat.setText(datarow[2]);
                to.inputStokObat.setText(datarow[3]);    
                }
        } catch (Exception e) {
        }
    
    }
    
    
    @Override 
    public void kembalikeStokObat1(TambahObat so){
        StokObat o = new StokObat();
        o.setVisible(true);
        so.dispose();
    }
        
    @Override
    public void kembalikeStokObat(TambahStok to) throws SQLException{
        StokObat p = new StokObat();
        p.setVisible(true);
        to.dispose();
    }
    
   @Override
   public void cariStokObat(StokObat so) throws SQLException{
       so.tblmodel.getDataVector().removeAllElements();
       try{    
        Connection con = koneksi.getKoneksi();
        Statement stt = con.createStatement();
        String sql = "select * from tbl_obat where namaObat like '%" + so.inputNamaObat.getText()
                + "%'" + "or kodeObat like '%" + so.inputNamaObat.getText()+ "%'";
        ResultSet res = stt.executeQuery(sql);
    while(res.next())
          {
              Object[] ob= new Object[10];
              ob[0] = res.getString(1);
              ob[1] = res.getString(2);
              ob[2] = res.getString(3);
              ob[3] = res.getString(4);
              ob[4] = res.getString(5);
              
              so.tblmodel.addRow(ob);
              
          } 
      } catch (Exception e) {
          System.out.println(e);
      }
   }
   
    @Override
    public void cariObatTBL(PermintaanObat po) throws SQLException{
    po.tblmodel.getDataVector().removeAllElements();
        try{    
        Connection con = koneksi.getKoneksi();
        Statement stt = con.createStatement();
        String sql = "select * from tbl_obat where namaObat like '%" + po.inputCariObat.getText()
                + "%'" + "or kodeObat like '%" + po.inputCariObat.getText()+ "%'";
        ResultSet res = stt.executeQuery(sql);
    while(res.next())
          {
              Object[] ob= new Object[10];
              ob[0] = res.getString(1);
              ob[1] = res.getString(2);
              ob[2] = res.getString(3);
              ob[3] = res.getString(4);
              
              po.tblmodel.addRow(ob);
              
          } 
      } catch (Exception e) {
          System.out.println(e);
      }
    }
    
    @Override 
    public void hapusStok(StokObat so) throws SQLException{
        
try {
            
            DefaultTableModel model = (DefaultTableModel) so.tabelDaftarObat.getModel();
            int selectedRowIndex = so.tabelDaftarObat.getSelectedRow();

            String sql ="delete from tbl_obat where kodeObat='"+(model.getValueAt(selectedRowIndex, 0))+"'";
            Connection con = koneksi.getKoneksi();
            java.sql.PreparedStatement pst=con.prepareStatement(sql);
            pst.execute();
            JOptionPane.showMessageDialog(null, "berhasil di hapus");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
        finally{
    so.tblmodel.getDataVector().removeAllElements();
           Connection con = koneksi.getKoneksi();
          Statement stt = con.createStatement();
          String sql = "select * from tbl_obat";
          ResultSet res = stt.executeQuery(sql);
          while(res.next())
          {
              Object[] ob= new Object[20];
              ob[0] = res.getString(1);
              ob[1] = res.getString(2);
              ob[2] = res.getString(3);
              ob[3] = res.getString(4);
              ob[4] = res.getString(5);
              
              so.tblmodel.addRow(ob);
              
          }  
        }
        
    }
    
    @Override 
    public void tambahStok(StokObat so){
        try {
            TambahStok ts = new TambahStok();
            ts.setVisible(true);
            so.dispose();
        } catch (Exception e) {
        }
    }
    
    @Override
    public void tampilTabelObat(PermintaanObat po) throws SQLException{
        try {
          Connection con = koneksi.getKoneksi();
          Statement stt = con.createStatement();
          String sql = "select * from tbl_obat";
          ResultSet res = stt.executeQuery(sql);
          while(res.next())
          {
              Object[] ob= new Object[10];
              ob[0] = res.getString(1);
              ob[1] = res.getString(2);
              ob[2] = res.getString(3);
              ob[3] = res.getString(4);
              
              po.tblmodel.addRow(ob);
              
          } 
      } catch (Exception e) {
          System.out.println(e);
      }
    }
    
    @Override
    public void ExportObat(StokObat so) throws SQLException{
        int selectedRowIndex = so.tabelDaftarObat.getSelectedRow();
        DefaultTableModel model = (DefaultTableModel)so.tabelDaftarObat.getModel();
        try {
            FileOutputStream fos = new FileOutputStream("StokObatConverted.txt");
            PrintWriter pw = new PrintWriter(fos);
        
            pw.println("Kode Obat : " + (model.getValueAt(selectedRowIndex, 0).toString()));
            pw.println("Nama Obat : " + (model.getValueAt(selectedRowIndex, 1).toString()));
            pw.println("Jenis Obat : " + (model.getValueAt(selectedRowIndex, 2).toString()));
            pw.println("Satuan Obat : " + (model.getValueAt(selectedRowIndex, 3).toString()));
            pw.println("Stok Obat : " + (model.getValueAt(selectedRowIndex, 4).toString()));

        pw.close();
        } catch (Exception e) {
        }
    }
    @Override
    public void simpanObat(TambahObat to) throws SQLException{
        try{
        Connection con = koneksi.getKoneksi();
        String sql = "insert tbl_obat values(?,?,?,?,?)";
        PreparedStatement prepare = con.prepareStatement(sql);
        prepare.setString(1, to.inputKode.getText());
        prepare.setString(2, to.inputNamaObat.getText());
        prepare.setString(3, to.inputJenisObat.getText());
        prepare.setString(4, to.inputSatuanObat.getText());
        prepare.setString(5, to.inputStokObat.getText());
        prepare.executeUpdate();
        JOptionPane.showMessageDialog(null, "Data Berhasil Disimpan");
        prepare.close();
        }
    catch (Exception e){
        System.out.println(e);
    }
    }
    
    @Override
    public void navObat(PermintaanObat po) throws SQLException{
        StokObat to = new StokObat();
        to.setVisible(true);
        po.dispose();
    }
    @Override
    public void navTambahObat(StokObat so) throws SQLException{
        TambahObat to = new TambahObat();
        to.setVisible(true);
        so.dispose();
    }
    @Override
    public void tampilTabelStokObat(StokObat sob) throws SQLException{
        try {
             Connection con = koneksi.getKoneksi();
          Statement stt = con.createStatement();
          String sql = "select * from tbl_obat";
          ResultSet res = stt.executeQuery(sql);
          while(res.next())
          {
              Object[] ob= new Object[10];
              ob[0] = res.getString(1);
              ob[1] = res.getString(2);
              ob[2] = res.getString(3);
              ob[3] = res.getString(4);
              ob[4] = res.getString(5);
              
              sob.tblmodel.addRow(ob);
            }
        } catch (Exception e) {
            System.out.println("eror");
        }
    }
    
    
    @Override
    public void tampilKode(TambahObat to) throws SQLException{
       try { 
            Connection con = koneksi.getKoneksi();
        String sql = "select * from tbl_obat";
        PreparedStatement pst = con.prepareStatement(sql);
        ResultSet res =pst.executeQuery(sql);
            if (res.next()) {
                
                        Random r = new Random();
                        char huruf1 = (char)(r.nextInt(26)+'A');
                        char huruf2 = (char)(r.nextInt(26)+'A');
                        char huruf3 = (char)(r.nextInt(26)+'A');
                        char huruf4 = (char)(r.nextInt(26)+'A');
                        int hasil1 = 1 + r.nextInt( 9 );
                        int hasil2 = 1 + r.nextInt( 9 );
                        int hasil3 = 1 + r.nextInt( 9 );
                        int hasil4 = 1 + r.nextInt( 9 );
                String angka1 = Integer.toString(hasil1);
                String angka2 = Integer.toString(hasil2);
                String angka3 = Integer.toString(hasil3);
                String angka4 = Integer.toString(hasil4);
                

               to.inputKode.setText(angka1+huruf1+huruf2+angka2+huruf3+huruf4+angka4);  
               to.inputKode.setEditable(false);
            }

           }catch(Exception e){
           JOptionPane.showMessageDialog(null, e);
           }
     }
    
    @Override 
    public void TampilDropdown(PermintaanObat pob) throws SQLException{

        try {
        Connection con = koneksi.getKoneksi();
        String sql = "select Nama_Unit from tbl_unit";
        PreparedStatement pst = con.prepareStatement(sql);
        ResultSet res =pst.executeQuery(sql);
        while(res.next()){
            String nama = res.getString("nama_unit");
            pob.combo.addItem(nama);
        }
    } catch (Exception e) {
    }
        
        
    }
    
    
    @Override
    public void btnLogin(FormLogin login) throws SQLException{
        try {
            Connection con = koneksi.getKoneksi();
            String sql = "select * from tbl_pengguna where username_pengguna ='"+ login.txtUname.getText()+"'"
                    + "And password_pengguna='"+login.txtPass.getText()+"'";
            PreparedStatement pst = con.prepareStatement(sql);
            ResultSet res = pst.executeQuery(sql);
            if (res.next()) {
                if (login.txtUname.getText().equals(res.getString("username_pengguna"))&&
                        login.txtPass.getText().equals(res.getString("password_pengguna"))) {
                    JOptionPane.showMessageDialog(null, "berhasil login");
                    PermintaanObat zzz=new PermintaanObat();
                    zzz.setVisible(true);
                    FormLogin p = new FormLogin();
                    p.setVisible(false);
                }
            }else{
                JOptionPane.showMessageDialog(null, "username atau password salah");
                FormLogin p = new FormLogin();
                p.setVisible(true);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(login, e.getMessage());
        }
        
    
    }

    @Override
    public void btnRiwayat(PermintaanObat PO){
        RiwayatPermintaanObat z = new RiwayatPermintaanObat();
        z.setVisible(true);
        PO.setVisible(false);
    }
    
    
//    @Override
//    public void btnKembaliPO(RiwayatPermintaanObat po) {
//    
//    po.setVisible(true);
//    
//    }
}
