package com.view;
import com.model.model_apl;
import com.view.FormLogin;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
/**
 *
 * @author Kresna Rachmadika
 */
public class StokObat extends javax.swing.JFrame {
public DefaultTableModel tblmodel;
String header [] = {"kode_obat", "nama_obat", "jenis", "satuan", "stok"};

    
private String getTanggal() {          
    DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");          
    Date date = new Date(); 
    return dateFormat.format(date);      
}
    

public StokObat() {
    initComponents();  
    tblmodel = new DefaultTableModel(null, header);
    tabelDaftarObat.setModel(tblmodel);
       
    try {
        model.tampilTabelStokObat(this);
    } catch (Exception e) {
    }
    tanggalSekarang.setText(getTanggal());
    }
    @SuppressWarnings("unchecked")
    model_apl model = new model_apl();
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        panelStokObat = new javax.swing.JPanel();
        labelStokObat = new javax.swing.JLabel();
        labelNamaObat = new javax.swing.JLabel();
        inputNamaObat = new javax.swing.JTextField();
        cariNamaObat = new javax.swing.JButton();
        panelTabelDaftarObat = new javax.swing.JScrollPane();
        tabelDaftarObat = new javax.swing.JTable();
        tambahObat = new javax.swing.JButton();
        hapusObat = new javax.swing.JButton();
        tambahStokObat = new javax.swing.JButton();
        tanggalSekarang = new javax.swing.JLabel();
        menuBar = new javax.swing.JPanel();
        menuLaporan = new javax.swing.JPanel();
        labelMenuLaporan = new javax.swing.JLabel();
        menuPermintaanObat = new javax.swing.JPanel();
        labelMenuPermintaanObat = new javax.swing.JLabel();
        menuStok = new javax.swing.JPanel();
        labelMenuStok = new javax.swing.JLabel();
        menuLogout = new javax.swing.JPanel();
        labelLogout = new javax.swing.JLabel();
        icon = new javax.swing.JLabel();
        iconLogout = new javax.swing.JLabel();
        btnExport = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);

        panelStokObat.setBackground(new java.awt.Color(255, 87, 87));
        panelStokObat.setMinimumSize(new java.awt.Dimension(0, 0));
        panelStokObat.setPreferredSize(new java.awt.Dimension(1280, 720));
        panelStokObat.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        labelStokObat.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        labelStokObat.setForeground(new java.awt.Color(255, 255, 255));
        labelStokObat.setText("Stok Obat");
        panelStokObat.add(labelStokObat, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 110, -1, -1));

        labelNamaObat.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        labelNamaObat.setForeground(new java.awt.Color(255, 255, 255));
        labelNamaObat.setText("Nama Obat");
        panelStokObat.add(labelNamaObat, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 180, -1, -1));

        inputNamaObat.setFont(new java.awt.Font("Segoe UI", 0, 12)); // NOI18N
        panelStokObat.add(inputNamaObat, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 180, 180, 30));

        cariNamaObat.setFont(new java.awt.Font("Segoe UI", 0, 12)); // NOI18N
        cariNamaObat.setText("Cari");
        cariNamaObat.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cariNamaObatActionPerformed(evt);
            }
        });
        panelStokObat.add(cariNamaObat, new org.netbeans.lib.awtextra.AbsoluteConstraints(730, 180, 60, 30));

        tabelDaftarObat.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "kode_obat", "nama_obat", "jenis", "satuan", "stok"
            }
        ));
        panelTabelDaftarObat.setViewportView(tabelDaftarObat);

        panelStokObat.add(panelTabelDaftarObat, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 250, 1070, 400));

        tambahObat.setFont(new java.awt.Font("Segoe UI", 0, 12)); // NOI18N
        tambahObat.setText("Tambah Obat");
        tambahObat.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tambahObatActionPerformed(evt);
            }
        });
        panelStokObat.add(tambahObat, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 670, -1, 30));

        hapusObat.setFont(new java.awt.Font("Segoe UI", 0, 12)); // NOI18N
        hapusObat.setText("Hapus");
        hapusObat.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                hapusObatActionPerformed(evt);
            }
        });
        panelStokObat.add(hapusObat, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 670, -1, 30));

        tambahStokObat.setFont(new java.awt.Font("Segoe UI", 0, 12)); // NOI18N
        tambahStokObat.setText("Tambah Stok");
        tambahStokObat.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tambahStokObatActionPerformed(evt);
            }
        });
        panelStokObat.add(tambahStokObat, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 670, -1, 30));

        tanggalSekarang.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        tanggalSekarang.setForeground(new java.awt.Color(255, 255, 255));
        panelStokObat.add(tanggalSekarang, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 110, 150, 30));

        menuBar.setBackground(new java.awt.Color(255, 255, 255));
        menuBar.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        menuLaporan.setBackground(new java.awt.Color(255, 255, 255));
        menuLaporan.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 87, 87), 2));
        menuLaporan.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                menuLaporanMouseClicked(evt);
            }
        });

        labelMenuLaporan.setBackground(new java.awt.Color(255, 87, 87));
        labelMenuLaporan.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        labelMenuLaporan.setForeground(new java.awt.Color(255, 87, 87));
        labelMenuLaporan.setText("Laporan");

        javax.swing.GroupLayout menuLaporanLayout = new javax.swing.GroupLayout(menuLaporan);
        menuLaporan.setLayout(menuLaporanLayout);
        menuLaporanLayout.setHorizontalGroup(
            menuLaporanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, menuLaporanLayout.createSequentialGroup()
                .addContainerGap(47, Short.MAX_VALUE)
                .addComponent(labelMenuLaporan)
                .addGap(46, 46, 46))
        );
        menuLaporanLayout.setVerticalGroup(
            menuLaporanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(menuLaporanLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(labelMenuLaporan, javax.swing.GroupLayout.DEFAULT_SIZE, 34, Short.MAX_VALUE)
                .addContainerGap())
        );

        menuBar.add(menuLaporan, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 0, 160, 60));

        menuPermintaanObat.setBackground(new java.awt.Color(255, 255, 255));
        menuPermintaanObat.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 87, 87), 2));
        menuPermintaanObat.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                menuPermintaanObatMouseClicked(evt);
            }
        });
        menuPermintaanObat.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        labelMenuPermintaanObat.setBackground(new java.awt.Color(255, 87, 87));
        labelMenuPermintaanObat.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        labelMenuPermintaanObat.setForeground(new java.awt.Color(255, 87, 87));
        labelMenuPermintaanObat.setText("Permintaan Obat");
        labelMenuPermintaanObat.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                labelMenuPermintaanObatMouseClicked(evt);
            }
        });
        menuPermintaanObat.add(labelMenuPermintaanObat, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 20, 140, 20));

        menuBar.add(menuPermintaanObat, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 0, 160, 60));

        menuStok.setBackground(new java.awt.Color(255, 87, 87));
        menuStok.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 87, 87), 2));
        menuStok.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                menuStokMouseClicked(evt);
            }
        });

        labelMenuStok.setBackground(new java.awt.Color(255, 87, 87));
        labelMenuStok.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        labelMenuStok.setForeground(new java.awt.Color(255, 255, 255));
        labelMenuStok.setText("Stok");

        javax.swing.GroupLayout menuStokLayout = new javax.swing.GroupLayout(menuStok);
        menuStok.setLayout(menuStokLayout);
        menuStokLayout.setHorizontalGroup(
            menuStokLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(menuStokLayout.createSequentialGroup()
                .addGap(62, 62, 62)
                .addComponent(labelMenuStok)
                .addContainerGap(59, Short.MAX_VALUE))
        );
        menuStokLayout.setVerticalGroup(
            menuStokLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(menuStokLayout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(labelMenuStok)
                .addContainerGap(15, Short.MAX_VALUE))
        );

        menuBar.add(menuStok, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 0, 160, 60));

        menuLogout.setBackground(new java.awt.Color(255, 255, 255));
        menuLogout.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                menuLogoutMouseClicked(evt);
            }
        });

        labelLogout.setBackground(new java.awt.Color(255, 87, 87));
        labelLogout.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        labelLogout.setForeground(new java.awt.Color(255, 87, 87));
        labelLogout.setText("Logout");

        javax.swing.GroupLayout menuLogoutLayout = new javax.swing.GroupLayout(menuLogout);
        menuLogout.setLayout(menuLogoutLayout);
        menuLogoutLayout.setHorizontalGroup(
            menuLogoutLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, menuLogoutLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(labelLogout, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        menuLogoutLayout.setVerticalGroup(
            menuLogoutLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(menuLogoutLayout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(labelLogout)
                .addContainerGap(19, Short.MAX_VALUE))
        );

        menuBar.add(menuLogout, new org.netbeans.lib.awtextra.AbsoluteConstraints(1190, 0, 90, 60));

        icon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/icons8-pill-30.png"))); // NOI18N
        icon.setText("jLabel1");
        menuBar.add(icon, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 10, 30, -1));

        iconLogout.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/icons8-exit-filled-30.png"))); // NOI18N
        menuBar.add(iconLogout, new org.netbeans.lib.awtextra.AbsoluteConstraints(1160, 10, -1, -1));

        panelStokObat.add(menuBar, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1280, 60));

        btnExport.setText("Export");
        btnExport.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnExportActionPerformed(evt);
            }
        });
        panelStokObat.add(btnExport, new org.netbeans.lib.awtextra.AbsoluteConstraints(1090, 670, 90, 30));

        jPanel1.setBackground(new java.awt.Color(113, 53, 49));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        panelStokObat.add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 90, 1220, 600));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(panelStokObat, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(panelStokObat, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void hapusObatActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_hapusObatActionPerformed
        try {
            model.hapusStok(this);
        } catch (Exception e) {
        }
    }//GEN-LAST:event_hapusObatActionPerformed

    private void tambahObatActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tambahObatActionPerformed
        try {
            model.navTambahObat(this);
        } catch (Exception e) {
        }
    }//GEN-LAST:event_tambahObatActionPerformed

    private void cariNamaObatActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cariNamaObatActionPerformed
        // TODO add your handling code here:
        try {
            model.cariStokObat(this);
        } catch (Exception e) {
        }
    }//GEN-LAST:event_cariNamaObatActionPerformed

    private void tambahStokObatActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tambahStokObatActionPerformed
        try {
            model.tambahStok(this);
        } catch (Exception e) {
        }
    }//GEN-LAST:event_tambahStokObatActionPerformed

    private void menuLaporanMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_menuLaporanMouseClicked
       
    }//GEN-LAST:event_menuLaporanMouseClicked

    private void labelMenuPermintaanObatMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_labelMenuPermintaanObatMouseClicked
        
    }//GEN-LAST:event_labelMenuPermintaanObatMouseClicked

    private void menuStokMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_menuStokMouseClicked
        
    }//GEN-LAST:event_menuStokMouseClicked

    private void menuLogoutMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_menuLogoutMouseClicked
       
    }//GEN-LAST:event_menuLogoutMouseClicked

    private void menuPermintaanObatMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_menuPermintaanObatMouseClicked
        // TODO add your handling code here:
        try {
            model.menuPermintaanObatSO(this);
        } catch (Exception e) {
        }
    }//GEN-LAST:event_menuPermintaanObatMouseClicked

    private void btnExportActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnExportActionPerformed
        // TODO add your handling code here:
        try {
            model.ExportObat(this);
        } catch (Exception e) {
        }
    }//GEN-LAST:event_btnExportActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
      
        
        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new FormLogin().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    public javax.swing.JButton btnExport;
    public javax.swing.JButton cariNamaObat;
    public javax.swing.JButton hapusObat;
    private javax.swing.JLabel icon;
    private javax.swing.JLabel iconLogout;
    public javax.swing.JTextField inputNamaObat;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel labelLogout;
    private javax.swing.JLabel labelMenuLaporan;
    private javax.swing.JLabel labelMenuPermintaanObat;
    private javax.swing.JLabel labelMenuStok;
    private javax.swing.JLabel labelNamaObat;
    private javax.swing.JLabel labelStokObat;
    private javax.swing.JPanel menuBar;
    private javax.swing.JPanel menuLaporan;
    private javax.swing.JPanel menuLogout;
    private javax.swing.JPanel menuPermintaanObat;
    private javax.swing.JPanel menuStok;
    public javax.swing.JPanel panelStokObat;
    public javax.swing.JScrollPane panelTabelDaftarObat;
    public javax.swing.JTable tabelDaftarObat;
    public javax.swing.JButton tambahObat;
    public javax.swing.JButton tambahStokObat;
    private javax.swing.JLabel tanggalSekarang;
    // End of variables declaration//GEN-END:variables
}
