/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.view;
import com.model.model_apl;
import java.awt.event.KeyEvent;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
/**
 *
 * @author Kresna Rachmadika
 */
public class TambahObat extends javax.swing.JFrame {

    /**
     * Creates new form NewJFrame
     */
public TambahObat() {
    initComponents();
    try {
        model.tampilKode(this);
    } catch (Exception e) {
    }
}
public void stok(KeyEvent a){
    if (Character.isAlphabetic(a.getKeyChar())) {
        a.consume();
        JOptionPane.showMessageDialog(null, "Isi stok menggunakan ANGKA", "Peringatan", JOptionPane.WARNING_MESSAGE);
    }
}
    model_apl model = new model_apl();
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        panelTambahObat = new javax.swing.JPanel();
        menuBar = new javax.swing.JPanel();
        menuLaporan = new javax.swing.JPanel();
        labelMenuLaporan = new javax.swing.JLabel();
        menuPermintaanObat = new javax.swing.JPanel();
        labelMenuPermintaanObat = new javax.swing.JLabel();
        menuStok = new javax.swing.JPanel();
        labelMenuStok = new javax.swing.JLabel();
        menuLogout = new javax.swing.JPanel();
        labelLogout = new javax.swing.JLabel();
        icon = new javax.swing.JLabel();
        iconLogout = new javax.swing.JLabel();
        labelKodeObat = new javax.swing.JLabel();
        labelNamaObat = new javax.swing.JLabel();
        labelJenisObat = new javax.swing.JLabel();
        labelSatuanObat = new javax.swing.JLabel();
        labelStokObat = new javax.swing.JLabel();
        inputKode = new javax.swing.JTextField();
        inputNamaObat = new javax.swing.JTextField();
        inputJenisObat = new javax.swing.JTextField();
        inputSatuanObat = new javax.swing.JTextField();
        inputStokObat = new javax.swing.JTextField();
        buttonKembali = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        buttonSimpan = new javax.swing.JButton();
        btnImport = new javax.swing.JButton();
        labelTambahObat = new javax.swing.JLabel();
        txtFile = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);

        panelTambahObat.setBackground(new java.awt.Color(255, 87, 87));
        panelTambahObat.setMinimumSize(new java.awt.Dimension(0, 0));
        panelTambahObat.setPreferredSize(new java.awt.Dimension(1280, 720));
        panelTambahObat.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        menuBar.setBackground(new java.awt.Color(255, 255, 255));
        menuBar.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        menuLaporan.setBackground(new java.awt.Color(255, 255, 255));
        menuLaporan.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 87, 87), 2));
        menuLaporan.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                menuLaporanMouseClicked(evt);
            }
        });

        labelMenuLaporan.setBackground(new java.awt.Color(255, 87, 87));
        labelMenuLaporan.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        labelMenuLaporan.setForeground(new java.awt.Color(255, 87, 87));
        labelMenuLaporan.setText("Laporan");

        javax.swing.GroupLayout menuLaporanLayout = new javax.swing.GroupLayout(menuLaporan);
        menuLaporan.setLayout(menuLaporanLayout);
        menuLaporanLayout.setHorizontalGroup(
            menuLaporanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, menuLaporanLayout.createSequentialGroup()
                .addContainerGap(47, Short.MAX_VALUE)
                .addComponent(labelMenuLaporan)
                .addGap(46, 46, 46))
        );
        menuLaporanLayout.setVerticalGroup(
            menuLaporanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(menuLaporanLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(labelMenuLaporan, javax.swing.GroupLayout.DEFAULT_SIZE, 34, Short.MAX_VALUE)
                .addContainerGap())
        );

        menuBar.add(menuLaporan, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 0, 160, 60));

        menuPermintaanObat.setBackground(new java.awt.Color(255, 255, 255));
        menuPermintaanObat.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 87, 87), 2));
        menuPermintaanObat.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                menuPermintaanObatMouseClicked(evt);
            }
        });
        menuPermintaanObat.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        labelMenuPermintaanObat.setBackground(new java.awt.Color(255, 87, 87));
        labelMenuPermintaanObat.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        labelMenuPermintaanObat.setForeground(new java.awt.Color(255, 87, 87));
        labelMenuPermintaanObat.setText("Permintaan Obat");
        labelMenuPermintaanObat.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                labelMenuPermintaanObatMouseClicked(evt);
            }
        });
        menuPermintaanObat.add(labelMenuPermintaanObat, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 20, 140, 20));

        menuBar.add(menuPermintaanObat, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 0, 160, 60));

        menuStok.setBackground(new java.awt.Color(255, 87, 87));
        menuStok.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 87, 87), 2));
        menuStok.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                menuStokMouseClicked(evt);
            }
        });

        labelMenuStok.setBackground(new java.awt.Color(255, 87, 87));
        labelMenuStok.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        labelMenuStok.setForeground(new java.awt.Color(255, 255, 255));
        labelMenuStok.setText("Stok");

        javax.swing.GroupLayout menuStokLayout = new javax.swing.GroupLayout(menuStok);
        menuStok.setLayout(menuStokLayout);
        menuStokLayout.setHorizontalGroup(
            menuStokLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(menuStokLayout.createSequentialGroup()
                .addGap(62, 62, 62)
                .addComponent(labelMenuStok)
                .addContainerGap(59, Short.MAX_VALUE))
        );
        menuStokLayout.setVerticalGroup(
            menuStokLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(menuStokLayout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(labelMenuStok)
                .addContainerGap(15, Short.MAX_VALUE))
        );

        menuBar.add(menuStok, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 0, 160, 60));

        menuLogout.setBackground(new java.awt.Color(255, 255, 255));
        menuLogout.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                menuLogoutMouseClicked(evt);
            }
        });

        labelLogout.setBackground(new java.awt.Color(255, 87, 87));
        labelLogout.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        labelLogout.setForeground(new java.awt.Color(255, 87, 87));
        labelLogout.setText("Logout");

        javax.swing.GroupLayout menuLogoutLayout = new javax.swing.GroupLayout(menuLogout);
        menuLogout.setLayout(menuLogoutLayout);
        menuLogoutLayout.setHorizontalGroup(
            menuLogoutLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, menuLogoutLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(labelLogout, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        menuLogoutLayout.setVerticalGroup(
            menuLogoutLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(menuLogoutLayout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(labelLogout)
                .addContainerGap(19, Short.MAX_VALUE))
        );

        menuBar.add(menuLogout, new org.netbeans.lib.awtextra.AbsoluteConstraints(1190, 0, 90, 60));

        icon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/icons8-pill-30.png"))); // NOI18N
        icon.setText("jLabel1");
        menuBar.add(icon, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 10, 30, -1));

        iconLogout.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/icons8-exit-filled-30.png"))); // NOI18N
        menuBar.add(iconLogout, new org.netbeans.lib.awtextra.AbsoluteConstraints(1160, 10, -1, -1));

        panelTambahObat.add(menuBar, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1280, 60));

        labelKodeObat.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        labelKodeObat.setForeground(new java.awt.Color(255, 255, 255));
        labelKodeObat.setText("Kode Obat");
        panelTambahObat.add(labelKodeObat, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 280, -1, -1));

        labelNamaObat.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        labelNamaObat.setForeground(new java.awt.Color(255, 255, 255));
        labelNamaObat.setText("Nama Obat");
        panelTambahObat.add(labelNamaObat, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 320, -1, -1));

        labelJenisObat.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        labelJenisObat.setForeground(new java.awt.Color(255, 255, 255));
        labelJenisObat.setText("Jenis");
        panelTambahObat.add(labelJenisObat, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 360, -1, -1));

        labelSatuanObat.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        labelSatuanObat.setForeground(new java.awt.Color(255, 255, 255));
        labelSatuanObat.setText("Satuan");
        panelTambahObat.add(labelSatuanObat, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 400, -1, -1));

        labelStokObat.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        labelStokObat.setForeground(new java.awt.Color(255, 255, 255));
        labelStokObat.setText("Stok");
        panelTambahObat.add(labelStokObat, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 440, -1, -1));

        inputKode.setFont(new java.awt.Font("Segoe UI", 0, 12)); // NOI18N
        panelTambahObat.add(inputKode, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 280, 230, 30));

        inputNamaObat.setFont(new java.awt.Font("Segoe UI", 0, 12)); // NOI18N
        panelTambahObat.add(inputNamaObat, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 320, 230, 30));

        inputJenisObat.setFont(new java.awt.Font("Segoe UI", 0, 12)); // NOI18N
        panelTambahObat.add(inputJenisObat, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 360, 230, 30));

        inputSatuanObat.setFont(new java.awt.Font("Segoe UI", 0, 12)); // NOI18N
        panelTambahObat.add(inputSatuanObat, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 400, 230, 30));

        inputStokObat.setFont(new java.awt.Font("Segoe UI", 0, 12)); // NOI18N
        inputStokObat.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inputStokObatActionPerformed(evt);
            }
        });
        inputStokObat.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                inputStokObatKeyTyped(evt);
            }
        });
        panelTambahObat.add(inputStokObat, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 440, 230, 30));

        buttonKembali.setFont(new java.awt.Font("Segoe UI", 0, 12)); // NOI18N
        buttonKembali.setText("Kembali");
        buttonKembali.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonKembaliActionPerformed(evt);
            }
        });
        panelTambahObat.add(buttonKembali, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 670, -1, 30));

        jPanel1.setBackground(new java.awt.Color(113, 53, 49));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        buttonSimpan.setFont(new java.awt.Font("Segoe UI", 0, 12)); // NOI18N
        buttonSimpan.setText("Simpan");
        buttonSimpan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonSimpanActionPerformed(evt);
            }
        });
        jPanel1.add(buttonSimpan, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 410, -1, 30));

        btnImport.setText("Import File");
        btnImport.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnImportActionPerformed(evt);
            }
        });
        jPanel1.add(btnImport, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 90, 110, 30));

        labelTambahObat.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        labelTambahObat.setForeground(new java.awt.Color(255, 255, 255));
        labelTambahObat.setText("Tambah Obat");
        jPanel1.add(labelTambahObat, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 30, -1, -1));
        jPanel1.add(txtFile, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 90, 230, 30));

        panelTambahObat.add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 120, 520, 540));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addComponent(panelTambahObat, javax.swing.GroupLayout.PREFERRED_SIZE, 1280, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(panelTambahObat, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void buttonKembaliActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonKembaliActionPerformed
        try {
            model.kembalikeStokObat1(this);
        } catch (Exception e) {
        }
    }//GEN-LAST:event_buttonKembaliActionPerformed

    private void buttonSimpanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonSimpanActionPerformed
        try {
            model.simpanObat(this);
        } catch (Exception e) {
        }
    }//GEN-LAST:event_buttonSimpanActionPerformed

    private void inputStokObatKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_inputStokObatKeyTyped
        stok(evt);
    }//GEN-LAST:event_inputStokObatKeyTyped

    private void inputStokObatActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inputStokObatActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_inputStokObatActionPerformed

    private void menuLaporanMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_menuLaporanMouseClicked
  
    }//GEN-LAST:event_menuLaporanMouseClicked

    private void labelMenuPermintaanObatMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_labelMenuPermintaanObatMouseClicked
       
    }//GEN-LAST:event_labelMenuPermintaanObatMouseClicked

    private void menuStokMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_menuStokMouseClicked
  
    }//GEN-LAST:event_menuStokMouseClicked

    private void menuLogoutMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_menuLogoutMouseClicked
       
    }//GEN-LAST:event_menuLogoutMouseClicked

    private void btnImportActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnImportActionPerformed
        // TODO add your handling code here:
        try {
            model.importfile(this);
        } catch (Exception e) {
        }
    }//GEN-LAST:event_btnImportActionPerformed

    private void menuPermintaanObatMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_menuPermintaanObatMouseClicked
        // TODO add your handling code here:
        
    }//GEN-LAST:event_menuPermintaanObatMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
       
        //</editor-fold>
        
        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new FormLogin().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    public javax.swing.JButton btnImport;
    public javax.swing.JButton buttonKembali;
    public javax.swing.JButton buttonSimpan;
    private javax.swing.JLabel icon;
    private javax.swing.JLabel iconLogout;
    public javax.swing.JTextField inputJenisObat;
    public javax.swing.JTextField inputKode;
    public javax.swing.JTextField inputNamaObat;
    public javax.swing.JTextField inputSatuanObat;
    public javax.swing.JTextField inputStokObat;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel labelJenisObat;
    private javax.swing.JLabel labelKodeObat;
    private javax.swing.JLabel labelLogout;
    private javax.swing.JLabel labelMenuLaporan;
    private javax.swing.JLabel labelMenuPermintaanObat;
    private javax.swing.JLabel labelMenuStok;
    private javax.swing.JLabel labelNamaObat;
    private javax.swing.JLabel labelSatuanObat;
    private javax.swing.JLabel labelStokObat;
    private javax.swing.JLabel labelTambahObat;
    private javax.swing.JPanel menuBar;
    private javax.swing.JPanel menuLaporan;
    private javax.swing.JPanel menuLogout;
    private javax.swing.JPanel menuPermintaanObat;
    private javax.swing.JPanel menuStok;
    private javax.swing.JPanel panelTambahObat;
    public javax.swing.JTextField txtFile;
    // End of variables declaration//GEN-END:variables
}
