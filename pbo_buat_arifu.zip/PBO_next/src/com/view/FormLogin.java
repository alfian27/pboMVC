package com.view;

import com.model.model_apl;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Kresna Rachmadika
 */
public class FormLogin extends javax.swing.JFrame {
    
    
    public FormLogin() {
        initComponents();
    }
    model_apl model = new model_apl();
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        panelLogin = new javax.swing.JPanel();
        txtUname = new javax.swing.JTextField();
        txtPass = new javax.swing.JPasswordField();
        labelUsername = new javax.swing.JLabel();
        labelPassword = new javax.swing.JLabel();
        buttonLogin = new javax.swing.JButton();
        buttonDaftar = new javax.swing.JButton();
        buttonLupaPassword = new javax.swing.JButton();
        labelLogin = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);

        panelLogin.setBackground(new java.awt.Color(255, 87, 87));
        panelLogin.setMinimumSize(new java.awt.Dimension(0, 0));
        panelLogin.setPreferredSize(new java.awt.Dimension(1280, 720));
        panelLogin.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        txtUname.setFont(new java.awt.Font("Segoe UI Light", 0, 11)); // NOI18N
        txtUname.setToolTipText("Insert Username");
        txtUname.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtUnameActionPerformed(evt);
            }
        });
        panelLogin.add(txtUname, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 500, 460, 30));

        txtPass.setToolTipText("insert Password");
        txtPass.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtPassActionPerformed(evt);
            }
        });
        panelLogin.add(txtPass, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 550, 460, 30));

        labelUsername.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        labelUsername.setForeground(new java.awt.Color(255, 255, 255));
        labelUsername.setText("USERNAME");
        panelLogin.add(labelUsername, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 480, -1, -1));

        labelPassword.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        labelPassword.setForeground(new java.awt.Color(255, 255, 255));
        labelPassword.setText("PASSWORD");
        panelLogin.add(labelPassword, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 530, -1, -1));

        buttonLogin.setText("LOGIN");
        buttonLogin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonLoginActionPerformed(evt);
            }
        });
        panelLogin.add(buttonLogin, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 610, 90, 30));

        buttonDaftar.setText("DAFTAR");
        buttonDaftar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonDaftarActionPerformed(evt);
            }
        });
        panelLogin.add(buttonDaftar, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 680, 90, 30));

        buttonLupaPassword.setText("LUPA PASSWORD");
        buttonLupaPassword.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonLupaPasswordActionPerformed(evt);
            }
        });
        panelLogin.add(buttonLupaPassword, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 680, 120, 30));

        labelLogin.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        labelLogin.setForeground(new java.awt.Color(255, 255, 255));
        labelLogin.setText("LOGIN");
        panelLogin.add(labelLogin, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 400, -1, -1));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/bg baru.png"))); // NOI18N
        jLabel1.setText("jLabel1");
        panelLogin.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(panelLogin, javax.swing.GroupLayout.PREFERRED_SIZE, 640, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(panelLogin, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtUnameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtUnameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtUnameActionPerformed

    private void txtPassActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtPassActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtPassActionPerformed

    private void buttonLoginActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonLoginActionPerformed
      try {
            model.btnLogin(this);
            this.dispose();

        } catch(Exception x){
            
        }
    }//GEN-LAST:event_buttonLoginActionPerformed

    private void buttonDaftarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonDaftarActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_buttonDaftarActionPerformed

    private void buttonLupaPasswordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonLupaPasswordActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_buttonLupaPasswordActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
      
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new FormLogin().setVisible(true);
            }
        });
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    public javax.swing.JButton buttonDaftar;
    public javax.swing.JButton buttonLogin;
    public javax.swing.JButton buttonLupaPassword;
    public javax.swing.JLabel jLabel1;
    public javax.swing.JLabel labelLogin;
    public javax.swing.JLabel labelPassword;
    public javax.swing.JLabel labelUsername;
    private javax.swing.JPanel panelLogin;
    public javax.swing.JPasswordField txtPass;
    public javax.swing.JTextField txtUname;
    // End of variables declaration//GEN-END:variables
}
