package com.view;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.JFrame;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Kresna Rachmadika
 */
public class RiwayatLaporan extends javax.swing.JFrame {

    private JTextField s1;
    private JTextField s2;
    private JTextField s3;
    private JTextField s4;
    private JTextField s5;
    private JTextField s6;
    private JTextField s7;
    private JTextField s8;
    private JTextField s9;
    private JTextField s10;
    private JTextField s11;
    
    
    private String getTahun() {          
        DateFormat dateFormat = new SimpleDateFormat("yyyy");          
        Date thn = new Date(); 
        return dateFormat.format(thn); 
    }
    
    /**
     * Creates new form NewJFrame
     */
    private String getTanggal() {          
        DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");          
        Date date = new Date(); 
        return dateFormat.format(date);      
    }  
    
    
    public RiwayatLaporan(String inputNamaObat3, String inputNamaObat4,String x3, String x4, String x5, String x6,String x7,String inputBln) {
        initComponents();
        tanggalSekarang.setText(getTanggal());
        if (x3.equals("")&&x4.equals("")&&x5.equals("")&&x6.equals("")&&x7.equals("")&& inputNamaObat4.equals("")&&inputNamaObat3.equals("")&&inputBln.equals("")) {
            tabelDaftarObat.setModel(new javax.swing.table.DefaultTableModel(
                
            new Object [][] {
                {"AD20CD1", "Glimepiride", "Butir", "500", "490", "260", "123", "370", "32", "Februari", "2019"},
                {"SA15YZE", "Ibuprofen", "Mili Liter", "700","688", "300", "200", "120", "43", "Februari", "2019"},
                {"ML95DA4", "Isotretinoin", "Pcs.", "620","611", "210", "28", "500", "60", "Februari", "2019"},
                {"TR31YDG", "Metformin", "Pcs.", "443","431", "320", "210", "343", "10", "Februari", "2019"},
                {"FCDV21D", "Naproxen", "Mili Liter", "565","561", "211", "31", "120", "90", "Februari", "2019"},
                {"VTRU12C", "Orlistat", "Botol", "507","500", "129", "131", "346", "80", "Februari", "2019"},
                {"FSW34X7", "Pil KB", "Tablet", "643","570", "341", "21", "376", "123", "Februari", "2019"},
                {"32DSCF9", "Piroxicam", "Tablet", "192","160", "81", "39", "12", "3", "Februari", "2019"},
                {x3, x4, x5, inputNamaObat4, inputNamaObat3, x7 , x7, x6, x7,inputBln , x7},
                {null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "Kode", "nama obat", "satuan", "stok awal", "penerimaan", "persediaan", "pemakaian", "stok sisa", "permintaan", "bulan", "tahun"
            }
        ));
        
        }else{
        int persediaan = Integer.parseInt(inputNamaObat3)- Integer.parseInt(x7);
        tabelDaftarObat.setModel(new javax.swing.table.DefaultTableModel(
                
            new Object [][] {
                 {"AD20CD1", "Glimepiride", "Butir", "500", "490", "260", "123", "370", "32", "Februari", "2019"},
                {"SA15YZE", "Ibuprofen", "Mili Liter", "700","688", "300", "200", "120", "43", "Februari", "2019"},
                {"ML95DA4", "Isotretinoin", "Pcs.", "620","611", "210", "28", "500", "60", "Februari", "2019"},
                {"TR31YDG", "Metformin", "Pcs.", "443","431", "320", "210", "343", "10", "Februari", "2019"},
                {"FCDV21D", "Naproxen", "Mili Liter", "565","561", "211", "31", "120", "90", "Februari", "2019"},
                {"VTRU12C", "Orlistat", "Botol", "507","500", "129", "131", "346", "80", "Februari", "2019"},
                {"FSW34X7", "Pil KB", "Tablet", "643","570", "341", "21", "376", "123", "Februari", "2019"},
                {"32DSCF9", "Piroxicam", "Tablet", "192","160", "81", "39", "12", "3", "Februari", "2019"},
                {x3, x4, x5, inputNamaObat4, inputNamaObat3, persediaan, x7, x6, x7,inputBln , getTahun()},
                {null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "Kode", "nama obat", "satuan", "stok awal", "penerimaan", "persediaan", "pemakaian", "stok sisa", "permintaan", "bulan", "tahun"
            }
        ));
        
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        panelRiwayatLaporan = new javax.swing.JPanel();
        labelStokObat = new javax.swing.JLabel();
        labeCariLaporan = new javax.swing.JLabel();
        cariLaporan = new javax.swing.JButton();
        panelTabelDaftarObat = new javax.swing.JScrollPane();
        tabelDaftarObat = new javax.swing.JTable();
        backLaporan = new javax.swing.JButton();
        exportLaporan = new javax.swing.JButton();
        tanggalSekarang = new javax.swing.JLabel();
        menuBar = new javax.swing.JPanel();
        icon = new javax.swing.JLabel();
        menuLaporan = new javax.swing.JPanel();
        labelMenuLaporan = new javax.swing.JLabel();
        menuPermintaanObat = new javax.swing.JPanel();
        labelMenuPermintaanObat = new javax.swing.JLabel();
        menuStok = new javax.swing.JPanel();
        labelMenuStok = new javax.swing.JLabel();
        menuLogout = new javax.swing.JPanel();
        labelLogout = new javax.swing.JLabel();
        iconLogout = new javax.swing.JLabel();
        buttonDetailLaporan = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setSize(new java.awt.Dimension(1280, 720));

        panelRiwayatLaporan.setBackground(new java.awt.Color(255, 87, 87));
        panelRiwayatLaporan.setMinimumSize(new java.awt.Dimension(0, 0));
        panelRiwayatLaporan.setPreferredSize(new java.awt.Dimension(1280, 720));
        panelRiwayatLaporan.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        labelStokObat.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        labelStokObat.setForeground(new java.awt.Color(255, 255, 255));
        labelStokObat.setText("Riwayat Laporan");
        panelRiwayatLaporan.add(labelStokObat, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 110, -1, -1));

        labeCariLaporan.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        labeCariLaporan.setForeground(new java.awt.Color(255, 255, 255));
        labeCariLaporan.setText("Cari Laporan");
        panelRiwayatLaporan.add(labeCariLaporan, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 170, -1, -1));

        cariLaporan.setFont(new java.awt.Font("Segoe UI", 0, 12)); // NOI18N
        cariLaporan.setText("Cari");
        cariLaporan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cariLaporanActionPerformed(evt);
            }
        });
        panelRiwayatLaporan.add(cariLaporan, new org.netbeans.lib.awtextra.AbsoluteConstraints(740, 170, 60, 30));

        tabelDaftarObat.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {"AD20CD1", "Glimepiride", "Butir", "500", "490", "260", "123", "70", "32", "Februari", "2019"},
                {null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "no", "nama obat", "satuan", "stok awal", "penerimaan", "persediaan", "pemakaian", "stok sisa", "permintaan", "bulan", "tahun"
            }
        ));
        panelTabelDaftarObat.setViewportView(tabelDaftarObat);

        panelRiwayatLaporan.add(panelTabelDaftarObat, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 240, 1160, 400));

        backLaporan.setFont(new java.awt.Font("Segoe UI", 0, 12)); // NOI18N
        backLaporan.setText("Kembali");
        backLaporan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backLaporanActionPerformed(evt);
            }
        });
        panelRiwayatLaporan.add(backLaporan, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 660, -1, 30));

        exportLaporan.setFont(new java.awt.Font("Segoe UI", 0, 12)); // NOI18N
        exportLaporan.setText("Export");
        exportLaporan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exportLaporanActionPerformed(evt);
            }
        });
        panelRiwayatLaporan.add(exportLaporan, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 660, -1, 30));

        tanggalSekarang.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        tanggalSekarang.setForeground(new java.awt.Color(255, 255, 255));
        panelRiwayatLaporan.add(tanggalSekarang, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 110, 150, 30));

        menuBar.setBackground(new java.awt.Color(255, 255, 255));
        menuBar.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        icon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/icons8-pill-30.png"))); // NOI18N
        icon.setText("jLabel1");
        menuBar.add(icon, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 10, 30, -1));

        menuLaporan.setBackground(new java.awt.Color(255, 87, 87));
        menuLaporan.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 87, 87), 2));
        menuLaporan.setForeground(new java.awt.Color(255, 87, 87));
        menuLaporan.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                menuLaporanMouseClicked(evt);
            }
        });

        labelMenuLaporan.setBackground(new java.awt.Color(255, 87, 87));
        labelMenuLaporan.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        labelMenuLaporan.setForeground(new java.awt.Color(255, 255, 255));
        labelMenuLaporan.setText("Laporan");

        javax.swing.GroupLayout menuLaporanLayout = new javax.swing.GroupLayout(menuLaporan);
        menuLaporan.setLayout(menuLaporanLayout);
        menuLaporanLayout.setHorizontalGroup(
            menuLaporanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, menuLaporanLayout.createSequentialGroup()
                .addContainerGap(47, Short.MAX_VALUE)
                .addComponent(labelMenuLaporan)
                .addGap(46, 46, 46))
        );
        menuLaporanLayout.setVerticalGroup(
            menuLaporanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(menuLaporanLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(labelMenuLaporan, javax.swing.GroupLayout.DEFAULT_SIZE, 34, Short.MAX_VALUE)
                .addContainerGap())
        );

        menuBar.add(menuLaporan, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 0, 160, 60));

        menuPermintaanObat.setBackground(new java.awt.Color(255, 255, 255));
        menuPermintaanObat.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 87, 87), 2));
        menuPermintaanObat.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        labelMenuPermintaanObat.setBackground(new java.awt.Color(255, 87, 87));
        labelMenuPermintaanObat.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        labelMenuPermintaanObat.setForeground(new java.awt.Color(255, 87, 87));
        labelMenuPermintaanObat.setText("Permintaan Obat");
        labelMenuPermintaanObat.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                labelMenuPermintaanObatMouseClicked(evt);
            }
        });
        menuPermintaanObat.add(labelMenuPermintaanObat, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 20, 140, 20));

        menuBar.add(menuPermintaanObat, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 0, 160, 60));

        menuStok.setBackground(new java.awt.Color(255, 255, 255));
        menuStok.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 87, 87), 2));
        menuStok.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                menuStokMouseClicked(evt);
            }
        });

        labelMenuStok.setBackground(new java.awt.Color(255, 87, 87));
        labelMenuStok.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        labelMenuStok.setForeground(new java.awt.Color(255, 87, 87));
        labelMenuStok.setText("Stok");

        javax.swing.GroupLayout menuStokLayout = new javax.swing.GroupLayout(menuStok);
        menuStok.setLayout(menuStokLayout);
        menuStokLayout.setHorizontalGroup(
            menuStokLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(menuStokLayout.createSequentialGroup()
                .addGap(62, 62, 62)
                .addComponent(labelMenuStok)
                .addContainerGap(59, Short.MAX_VALUE))
        );
        menuStokLayout.setVerticalGroup(
            menuStokLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(menuStokLayout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(labelMenuStok)
                .addContainerGap(15, Short.MAX_VALUE))
        );

        menuBar.add(menuStok, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 0, 160, 60));

        menuLogout.setBackground(new java.awt.Color(255, 255, 255));
        menuLogout.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                menuLogoutMouseClicked(evt);
            }
        });

        labelLogout.setBackground(new java.awt.Color(255, 87, 87));
        labelLogout.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        labelLogout.setForeground(new java.awt.Color(255, 87, 87));
        labelLogout.setText("Logout");

        javax.swing.GroupLayout menuLogoutLayout = new javax.swing.GroupLayout(menuLogout);
        menuLogout.setLayout(menuLogoutLayout);
        menuLogoutLayout.setHorizontalGroup(
            menuLogoutLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, menuLogoutLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(labelLogout, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        menuLogoutLayout.setVerticalGroup(
            menuLogoutLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(menuLogoutLayout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(labelLogout)
                .addContainerGap(19, Short.MAX_VALUE))
        );

        menuBar.add(menuLogout, new org.netbeans.lib.awtextra.AbsoluteConstraints(1190, 0, 90, 60));

        iconLogout.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/icons8-exit-filled-30.png"))); // NOI18N
        menuBar.add(iconLogout, new org.netbeans.lib.awtextra.AbsoluteConstraints(1160, 10, -1, -1));

        panelRiwayatLaporan.add(menuBar, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1280, 60));

        buttonDetailLaporan.setText("Detail Laporan");
        buttonDetailLaporan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonDetailLaporanActionPerformed(evt);
            }
        });
        panelRiwayatLaporan.add(buttonDetailLaporan, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 660, -1, 30));

        jPanel1.setBackground(new java.awt.Color(113, 53, 49));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        panelRiwayatLaporan.add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 90, 1220, 600));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(panelRiwayatLaporan, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(panelRiwayatLaporan, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void cariLaporanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cariLaporanActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cariLaporanActionPerformed

    private void exportLaporanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exportLaporanActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_exportLaporanActionPerformed

    private void backLaporanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backLaporanActionPerformed
        // TODO add your handling code here:
        MenuLaporanBulanan go = new MenuLaporanBulanan();
        go.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_backLaporanActionPerformed

    private void menuLaporanMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_menuLaporanMouseClicked
        MenuLaporanBulanan mm = new MenuLaporanBulanan();
        mm.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_menuLaporanMouseClicked

    private void labelMenuPermintaanObatMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_labelMenuPermintaanObatMouseClicked
        PermintaanObat zx = new PermintaanObat();
        zx.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_labelMenuPermintaanObatMouseClicked

    private void menuStokMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_menuStokMouseClicked
        // TODO add your handling code here:
        StokObat cc = new StokObat();
        cc.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_menuStokMouseClicked

    private void menuLogoutMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_menuLogoutMouseClicked

    }//GEN-LAST:event_menuLogoutMouseClicked

    private void buttonDetailLaporanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonDetailLaporanActionPerformed
        // TODO add your handling code here:
        DefaultTableModel model = (DefaultTableModel) tabelDaftarObat.getModel();
        int selectedRowIndex = tabelDaftarObat.getSelectedRow();
        
        s1 = new javax.swing.JTextField();
        s1.setText((model.getValueAt(selectedRowIndex, 0).toString()));
        s1.setVisible(false);
        
        s2 = new javax.swing.JTextField();
        s2.setText((model.getValueAt(selectedRowIndex, 1).toString()));
        s2.setVisible(false);
        
        s3 = new javax.swing.JTextField();
        s3.setText((model.getValueAt(selectedRowIndex, 2).toString()));
        s3.setVisible(false);
        
        s4 = new javax.swing.JTextField();
        s4.setText((model.getValueAt(selectedRowIndex, 3).toString()));
        s4.setVisible(false);
        
        s5 = new javax.swing.JTextField();
        s5.setText((model.getValueAt(selectedRowIndex, 4).toString()));
        s5.setVisible(false);
        
        s6 = new javax.swing.JTextField();
        s6.setText((model.getValueAt(selectedRowIndex, 5).toString()));
        s6.setVisible(false);
        
        s7 = new javax.swing.JTextField();
        s7.setText((model.getValueAt(selectedRowIndex, 6).toString()));
        s7.setVisible(false);
        
        s8 = new javax.swing.JTextField();
        s8.setText((model.getValueAt(selectedRowIndex, 7).toString()));
        s8.setVisible(false);
        
        s9 = new javax.swing.JTextField();
        s9.setText((model.getValueAt(selectedRowIndex, 8).toString()));
        s9.setVisible(false);
        
        s10 = new javax.swing.JTextField();
        s10.setText((model.getValueAt(selectedRowIndex, 9).toString()));
        s10.setVisible(false);
        
        s11 = new javax.swing.JTextField();
        s11.setText((model.getValueAt(selectedRowIndex, 10).toString()));
        s11.setVisible(false);
        
        
        detilLaporan zz = new detilLaporan(s1.getText(),s2.getText(),s3.getText(),s4.getText()
        ,s5.getText(),s6.getText(),s7.getText(),s8.getText(),s9.getText(),s10.getText(),s11.getText());
        zz.setVisible(true);
        this.dispose();
        
    }//GEN-LAST:event_buttonDetailLaporanActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
       
        //</editor-fold>
        
        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new FormLogin().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton backLaporan;
    private javax.swing.JButton buttonDetailLaporan;
    private javax.swing.JButton cariLaporan;
    private javax.swing.JButton exportLaporan;
    private javax.swing.JLabel icon;
    private javax.swing.JLabel iconLogout;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel labeCariLaporan;
    private javax.swing.JLabel labelLogout;
    private javax.swing.JLabel labelMenuLaporan;
    private javax.swing.JLabel labelMenuPermintaanObat;
    private javax.swing.JLabel labelMenuStok;
    private javax.swing.JLabel labelStokObat;
    private javax.swing.JPanel menuBar;
    private javax.swing.JPanel menuLaporan;
    private javax.swing.JPanel menuLogout;
    private javax.swing.JPanel menuPermintaanObat;
    private javax.swing.JPanel menuStok;
    private javax.swing.JPanel panelRiwayatLaporan;
    private javax.swing.JScrollPane panelTabelDaftarObat;
    private javax.swing.JTable tabelDaftarObat;
    private javax.swing.JLabel tanggalSekarang;
    // End of variables declaration//GEN-END:variables
}
