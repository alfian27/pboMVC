/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.view;
import com.model.model_apl;
import java.awt.Component;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;
/**
 *
 * @author Alfian
 */
public class PermintaanObat extends javax.swing.JFrame {
public DefaultTableModel tblmodel;
    String header[]={"Kode Obat", "NamaObat", "JenisObat", "SatuanObat"};

    public PermintaanObat() {
        initComponents();
        
        try {
            model.TampilDropdown(this);
        } catch (Exception e) {
        }
        
        tblmodel = new DefaultTableModel(null, header);
        tabelDaftarObat.setModel(tblmodel);
       
        
        try {
            model.tampilTabelObat(this);
        } catch (Exception e) {
        }
    }
    
    model_apl model = new model_apl();
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        panelPermintaanObat = new javax.swing.JPanel();
        menuBar = new javax.swing.JPanel();
        menuLaporan = new javax.swing.JPanel();
        labelMenuLaporan = new javax.swing.JLabel();
        menuPermintaanObat = new javax.swing.JPanel();
        labelMenuPermintaanObat = new javax.swing.JLabel();
        menuStok = new javax.swing.JPanel();
        labelMenuStok = new javax.swing.JLabel();
        menuLogout = new javax.swing.JPanel();
        labelLogout = new javax.swing.JLabel();
        icon = new javax.swing.JLabel();
        iconLogout = new javax.swing.JLabel();
        menuBar1 = new javax.swing.JPanel();
        menuLaporan1 = new javax.swing.JPanel();
        labelMenuLaporan1 = new javax.swing.JLabel();
        menuPermintaanObat1 = new javax.swing.JPanel();
        labelMenuPermintaanObat1 = new javax.swing.JLabel();
        menuStok1 = new javax.swing.JPanel();
        labelMenuStok1 = new javax.swing.JLabel();
        menuLogout1 = new javax.swing.JPanel();
        labelLogout1 = new javax.swing.JLabel();
        icon1 = new javax.swing.JLabel();
        iconLogout1 = new javax.swing.JLabel();
        tanggalSekarang = new javax.swing.JLabel();
        labelPermintaanObat = new javax.swing.JLabel();
        labelUnit = new javax.swing.JLabel();
        labelNamaPasien = new javax.swing.JLabel();
        inputNamaPasien = new javax.swing.JTextField();
        labelUmur = new javax.swing.JLabel();
        inputUmur = new javax.swing.JTextField();
        labelJenisKelamin = new javax.swing.JLabel();
        JKLaki = new javax.swing.JRadioButton();
        JKPerempuan = new javax.swing.JRadioButton();
        labelPekerjaan = new javax.swing.JLabel();
        inputPekerjaan = new javax.swing.JTextField();
        labelNamaKK = new javax.swing.JLabel();
        inputNamaKK = new javax.swing.JTextField();
        labelAlamat = new javax.swing.JLabel();
        panelInputAlamat = new javax.swing.JScrollPane();
        inputAlamat = new javax.swing.JTextArea();
        labelDiagnosis = new javax.swing.JLabel();
        inputDiagnosis = new javax.swing.JTextField();
        labelDaftarObat = new javax.swing.JLabel();
        labelCariObat = new javax.swing.JLabel();
        inputCariObat = new javax.swing.JTextField();
        buttonCariObat = new javax.swing.JButton();
        labelJumlah = new javax.swing.JLabel();
        inputJumlah = new javax.swing.JSpinner();
        buttonTambahObat = new javax.swing.JButton();
        labelPilihObat = new javax.swing.JLabel();
        panelTabelPilihObat = new javax.swing.JScrollPane();
        tabelPilihObat = new javax.swing.JTable();
        hapusObat = new javax.swing.JButton();
        btnRiwayat = new javax.swing.JButton();
        simpan = new javax.swing.JButton();
        combo = new javax.swing.JComboBox<>();
        jScrollPane1 = new javax.swing.JScrollPane();
        tabelDaftarObat = new javax.swing.JTable();
        jPanel1 = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        panelPermintaanObat.setBackground(new java.awt.Color(255, 87, 87));
        panelPermintaanObat.setMinimumSize(new java.awt.Dimension(0, 0));
        panelPermintaanObat.setPreferredSize(new java.awt.Dimension(1280, 720));
        panelPermintaanObat.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        menuBar.setBackground(new java.awt.Color(255, 255, 255));
        menuBar.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        menuLaporan.setBackground(new java.awt.Color(255, 255, 255));
        menuLaporan.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 87, 87), 2));
        menuLaporan.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                menuLaporanMouseClicked(evt);
            }
        });

        labelMenuLaporan.setBackground(new java.awt.Color(255, 87, 87));
        labelMenuLaporan.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        labelMenuLaporan.setForeground(new java.awt.Color(255, 87, 87));
        labelMenuLaporan.setText("Laporan");

        javax.swing.GroupLayout menuLaporanLayout = new javax.swing.GroupLayout(menuLaporan);
        menuLaporan.setLayout(menuLaporanLayout);
        menuLaporanLayout.setHorizontalGroup(
            menuLaporanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, menuLaporanLayout.createSequentialGroup()
                .addContainerGap(47, Short.MAX_VALUE)
                .addComponent(labelMenuLaporan)
                .addGap(46, 46, 46))
        );
        menuLaporanLayout.setVerticalGroup(
            menuLaporanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(menuLaporanLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(labelMenuLaporan, javax.swing.GroupLayout.DEFAULT_SIZE, 34, Short.MAX_VALUE)
                .addContainerGap())
        );

        menuBar.add(menuLaporan, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 0, 160, 60));

        menuPermintaanObat.setBackground(new java.awt.Color(255, 87, 87));
        menuPermintaanObat.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 87, 87), 2));
        menuPermintaanObat.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        labelMenuPermintaanObat.setBackground(new java.awt.Color(255, 87, 87));
        labelMenuPermintaanObat.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        labelMenuPermintaanObat.setForeground(new java.awt.Color(255, 255, 255));
        labelMenuPermintaanObat.setText("Permintaan Obat");
        labelMenuPermintaanObat.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                labelMenuPermintaanObatMouseClicked(evt);
            }
        });
        menuPermintaanObat.add(labelMenuPermintaanObat, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 20, 140, 20));

        menuBar.add(menuPermintaanObat, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 0, 160, 60));

        menuStok.setBackground(new java.awt.Color(255, 255, 255));
        menuStok.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 87, 87), 2));
        menuStok.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                menuStokMouseClicked(evt);
            }
        });

        labelMenuStok.setBackground(new java.awt.Color(255, 87, 87));
        labelMenuStok.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        labelMenuStok.setForeground(new java.awt.Color(255, 87, 87));
        labelMenuStok.setText("Stok");

        javax.swing.GroupLayout menuStokLayout = new javax.swing.GroupLayout(menuStok);
        menuStok.setLayout(menuStokLayout);
        menuStokLayout.setHorizontalGroup(
            menuStokLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(menuStokLayout.createSequentialGroup()
                .addGap(62, 62, 62)
                .addComponent(labelMenuStok)
                .addContainerGap(59, Short.MAX_VALUE))
        );
        menuStokLayout.setVerticalGroup(
            menuStokLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(menuStokLayout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(labelMenuStok)
                .addContainerGap(15, Short.MAX_VALUE))
        );

        menuBar.add(menuStok, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 0, 160, 60));

        menuLogout.setBackground(new java.awt.Color(255, 255, 255));
        menuLogout.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                menuLogoutMouseClicked(evt);
            }
        });

        labelLogout.setBackground(new java.awt.Color(255, 87, 87));
        labelLogout.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        labelLogout.setForeground(new java.awt.Color(255, 87, 87));
        labelLogout.setText("Logout");

        javax.swing.GroupLayout menuLogoutLayout = new javax.swing.GroupLayout(menuLogout);
        menuLogout.setLayout(menuLogoutLayout);
        menuLogoutLayout.setHorizontalGroup(
            menuLogoutLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, menuLogoutLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(labelLogout, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        menuLogoutLayout.setVerticalGroup(
            menuLogoutLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(menuLogoutLayout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(labelLogout)
                .addContainerGap(19, Short.MAX_VALUE))
        );

        menuBar.add(menuLogout, new org.netbeans.lib.awtextra.AbsoluteConstraints(1190, 0, 90, 60));

        icon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/icons8-pill-30.png"))); // NOI18N
        icon.setText("jLabel1");
        menuBar.add(icon, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 10, 30, -1));

        iconLogout.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/icons8-exit-filled-30.png"))); // NOI18N
        menuBar.add(iconLogout, new org.netbeans.lib.awtextra.AbsoluteConstraints(1160, 10, -1, -1));

        menuBar1.setBackground(new java.awt.Color(255, 255, 255));
        menuBar1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        menuLaporan1.setBackground(new java.awt.Color(255, 255, 255));
        menuLaporan1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 87, 87), 2));
        menuLaporan1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                menuLaporan1MouseClicked(evt);
            }
        });

        labelMenuLaporan1.setBackground(new java.awt.Color(255, 87, 87));
        labelMenuLaporan1.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        labelMenuLaporan1.setForeground(new java.awt.Color(255, 87, 87));
        labelMenuLaporan1.setText("Laporan");

        javax.swing.GroupLayout menuLaporan1Layout = new javax.swing.GroupLayout(menuLaporan1);
        menuLaporan1.setLayout(menuLaporan1Layout);
        menuLaporan1Layout.setHorizontalGroup(
            menuLaporan1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, menuLaporan1Layout.createSequentialGroup()
                .addContainerGap(47, Short.MAX_VALUE)
                .addComponent(labelMenuLaporan1)
                .addGap(46, 46, 46))
        );
        menuLaporan1Layout.setVerticalGroup(
            menuLaporan1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(menuLaporan1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(labelMenuLaporan1, javax.swing.GroupLayout.DEFAULT_SIZE, 34, Short.MAX_VALUE)
                .addContainerGap())
        );

        menuBar1.add(menuLaporan1, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 0, 160, 60));

        menuPermintaanObat1.setBackground(new java.awt.Color(255, 87, 87));
        menuPermintaanObat1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 87, 87), 2));
        menuPermintaanObat1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        labelMenuPermintaanObat1.setBackground(new java.awt.Color(255, 87, 87));
        labelMenuPermintaanObat1.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        labelMenuPermintaanObat1.setForeground(new java.awt.Color(255, 255, 255));
        labelMenuPermintaanObat1.setText("Permintaan Obat");
        labelMenuPermintaanObat1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                labelMenuPermintaanObat1MouseClicked(evt);
            }
        });
        menuPermintaanObat1.add(labelMenuPermintaanObat1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 20, 140, 20));

        menuBar1.add(menuPermintaanObat1, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 0, 160, 60));

        menuStok1.setBackground(new java.awt.Color(255, 255, 255));
        menuStok1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 87, 87), 2));
        menuStok1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                menuStok1MouseClicked(evt);
            }
        });

        labelMenuStok1.setBackground(new java.awt.Color(255, 87, 87));
        labelMenuStok1.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        labelMenuStok1.setForeground(new java.awt.Color(255, 87, 87));
        labelMenuStok1.setText("Stok");

        javax.swing.GroupLayout menuStok1Layout = new javax.swing.GroupLayout(menuStok1);
        menuStok1.setLayout(menuStok1Layout);
        menuStok1Layout.setHorizontalGroup(
            menuStok1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(menuStok1Layout.createSequentialGroup()
                .addGap(62, 62, 62)
                .addComponent(labelMenuStok1)
                .addContainerGap(59, Short.MAX_VALUE))
        );
        menuStok1Layout.setVerticalGroup(
            menuStok1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(menuStok1Layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(labelMenuStok1)
                .addContainerGap(15, Short.MAX_VALUE))
        );

        menuBar1.add(menuStok1, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 0, 160, 60));

        menuLogout1.setBackground(new java.awt.Color(255, 255, 255));
        menuLogout1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                menuLogout1MouseClicked(evt);
            }
        });

        labelLogout1.setBackground(new java.awt.Color(255, 87, 87));
        labelLogout1.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        labelLogout1.setForeground(new java.awt.Color(255, 87, 87));
        labelLogout1.setText("Logout");

        javax.swing.GroupLayout menuLogout1Layout = new javax.swing.GroupLayout(menuLogout1);
        menuLogout1.setLayout(menuLogout1Layout);
        menuLogout1Layout.setHorizontalGroup(
            menuLogout1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, menuLogout1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(labelLogout1, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        menuLogout1Layout.setVerticalGroup(
            menuLogout1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(menuLogout1Layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(labelLogout1)
                .addContainerGap(19, Short.MAX_VALUE))
        );

        menuBar1.add(menuLogout1, new org.netbeans.lib.awtextra.AbsoluteConstraints(1190, 0, 90, 60));

        icon1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/icons8-pill-30.png"))); // NOI18N
        icon1.setText("jLabel1");
        menuBar1.add(icon1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 10, 30, -1));

        iconLogout1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/icons8-exit-filled-30.png"))); // NOI18N
        menuBar1.add(iconLogout1, new org.netbeans.lib.awtextra.AbsoluteConstraints(1160, 10, -1, -1));

        menuBar.add(menuBar1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1280, 60));

        panelPermintaanObat.add(menuBar, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1280, 60));

        tanggalSekarang.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        tanggalSekarang.setForeground(new java.awt.Color(255, 255, 255));
        panelPermintaanObat.add(tanggalSekarang, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 110, 150, 30));

        labelPermintaanObat.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        labelPermintaanObat.setForeground(new java.awt.Color(255, 255, 255));
        labelPermintaanObat.setText("Permintaan Obat");
        panelPermintaanObat.add(labelPermintaanObat, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 110, -1, -1));

        labelUnit.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        labelUnit.setForeground(new java.awt.Color(255, 255, 255));
        labelUnit.setText("UNIT");
        panelPermintaanObat.add(labelUnit, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 220, -1, -1));

        labelNamaPasien.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        labelNamaPasien.setForeground(new java.awt.Color(255, 255, 255));
        labelNamaPasien.setText("Nama Pasien");
        panelPermintaanObat.add(labelNamaPasien, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 260, -1, -1));

        inputNamaPasien.setFont(new java.awt.Font("Segoe UI", 0, 12)); // NOI18N
        panelPermintaanObat.add(inputNamaPasien, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 260, 280, 30));

        labelUmur.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        labelUmur.setForeground(new java.awt.Color(255, 255, 255));
        labelUmur.setText("Umur");
        panelPermintaanObat.add(labelUmur, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 300, -1, -1));

        inputUmur.setFont(new java.awt.Font("Segoe UI", 0, 12)); // NOI18N
        inputUmur.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inputUmurActionPerformed(evt);
            }
        });
        inputUmur.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                inputUmurKeyTyped(evt);
            }
        });
        panelPermintaanObat.add(inputUmur, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 300, 80, 30));

        labelJenisKelamin.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        labelJenisKelamin.setForeground(new java.awt.Color(255, 255, 255));
        labelJenisKelamin.setText("Jenis Kelamin");
        panelPermintaanObat.add(labelJenisKelamin, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 340, -1, -1));

        JKLaki.setBackground(new java.awt.Color(113, 53, 49));
        buttonGroup1.add(JKLaki);
        JKLaki.setFont(new java.awt.Font("Segoe UI", 0, 12)); // NOI18N
        JKLaki.setForeground(new java.awt.Color(255, 255, 255));
        JKLaki.setText("Laki - laki");
        JKLaki.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JKLakiActionPerformed(evt);
            }
        });
        panelPermintaanObat.add(JKLaki, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 340, 90, 30));

        JKPerempuan.setBackground(new java.awt.Color(113, 53, 49));
        buttonGroup1.add(JKPerempuan);
        JKPerempuan.setFont(new java.awt.Font("Segoe UI", 0, 12)); // NOI18N
        JKPerempuan.setForeground(new java.awt.Color(255, 255, 255));
        JKPerempuan.setText("Perempuan");
        JKPerempuan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JKPerempuanActionPerformed(evt);
            }
        });
        panelPermintaanObat.add(JKPerempuan, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 340, 100, 30));

        labelPekerjaan.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        labelPekerjaan.setForeground(new java.awt.Color(255, 255, 255));
        labelPekerjaan.setText("Pekerjaan");
        panelPermintaanObat.add(labelPekerjaan, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 370, -1, -1));

        inputPekerjaan.setFont(new java.awt.Font("Segoe UI", 0, 12)); // NOI18N
        panelPermintaanObat.add(inputPekerjaan, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 370, 280, 30));

        labelNamaKK.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        labelNamaKK.setForeground(new java.awt.Color(255, 255, 255));
        labelNamaKK.setText("Nama KK");
        panelPermintaanObat.add(labelNamaKK, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 410, -1, -1));

        inputNamaKK.setFont(new java.awt.Font("Segoe UI", 0, 12)); // NOI18N
        panelPermintaanObat.add(inputNamaKK, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 410, 280, 30));

        labelAlamat.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        labelAlamat.setForeground(new java.awt.Color(255, 255, 255));
        labelAlamat.setText("Alamat");
        panelPermintaanObat.add(labelAlamat, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 450, -1, -1));

        inputAlamat.setColumns(20);
        inputAlamat.setFont(new java.awt.Font("Segoe UI", 0, 12)); // NOI18N
        inputAlamat.setRows(5);
        panelInputAlamat.setViewportView(inputAlamat);

        panelPermintaanObat.add(panelInputAlamat, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 450, 280, 80));

        labelDiagnosis.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        labelDiagnosis.setForeground(new java.awt.Color(255, 255, 255));
        labelDiagnosis.setText("Diagnosis");
        panelPermintaanObat.add(labelDiagnosis, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 540, -1, -1));

        inputDiagnosis.setFont(new java.awt.Font("Segoe UI", 0, 12)); // NOI18N
        inputDiagnosis.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inputDiagnosisActionPerformed(evt);
            }
        });
        panelPermintaanObat.add(inputDiagnosis, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 540, 280, 30));

        labelDaftarObat.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        labelDaftarObat.setForeground(new java.awt.Color(255, 255, 255));
        labelDaftarObat.setText("Daftar Obat");
        panelPermintaanObat.add(labelDaftarObat, new org.netbeans.lib.awtextra.AbsoluteConstraints(740, 180, -1, -1));

        labelCariObat.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        labelCariObat.setForeground(new java.awt.Color(255, 255, 255));
        labelCariObat.setText("Cari Obat");
        panelPermintaanObat.add(labelCariObat, new org.netbeans.lib.awtextra.AbsoluteConstraints(740, 340, -1, -1));

        inputCariObat.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inputCariObatActionPerformed(evt);
            }
        });
        panelPermintaanObat.add(inputCariObat, new org.netbeans.lib.awtextra.AbsoluteConstraints(830, 340, 280, 30));

        buttonCariObat.setFont(new java.awt.Font("Segoe UI", 0, 12)); // NOI18N
        buttonCariObat.setText("Cari");
        buttonCariObat.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonCariObatActionPerformed(evt);
            }
        });
        panelPermintaanObat.add(buttonCariObat, new org.netbeans.lib.awtextra.AbsoluteConstraints(1120, 340, 60, 30));

        labelJumlah.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        labelJumlah.setForeground(new java.awt.Color(255, 255, 255));
        labelJumlah.setText("Jumlah");
        panelPermintaanObat.add(labelJumlah, new org.netbeans.lib.awtextra.AbsoluteConstraints(740, 380, -1, -1));

        inputJumlah.setModel(new javax.swing.SpinnerNumberModel());
        panelPermintaanObat.add(inputJumlah, new org.netbeans.lib.awtextra.AbsoluteConstraints(830, 380, 70, 30));

        buttonTambahObat.setFont(new java.awt.Font("Segoe UI", 0, 12)); // NOI18N
        buttonTambahObat.setText("Tambah");
        buttonTambahObat.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonTambahObatActionPerformed(evt);
            }
        });
        panelPermintaanObat.add(buttonTambahObat, new org.netbeans.lib.awtextra.AbsoluteConstraints(910, 380, -1, 30));

        labelPilihObat.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        labelPilihObat.setForeground(new java.awt.Color(255, 255, 255));
        labelPilihObat.setText("Obat yang dipilih");
        panelPermintaanObat.add(labelPilihObat, new org.netbeans.lib.awtextra.AbsoluteConstraints(740, 420, -1, -1));

        tabelPilihObat.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "no", "nama obat", "satuan", "jumlah"
            }
        ));
        panelTabelPilihObat.setViewportView(tabelPilihObat);

        panelPermintaanObat.add(panelTabelPilihObat, new org.netbeans.lib.awtextra.AbsoluteConstraints(740, 450, 450, 90));

        hapusObat.setFont(new java.awt.Font("Segoe UI", 0, 12)); // NOI18N
        hapusObat.setText("Hapus Obat");
        hapusObat.setPreferredSize(new java.awt.Dimension(63, 23));
        hapusObat.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                hapusObatActionPerformed(evt);
            }
        });
        panelPermintaanObat.add(hapusObat, new org.netbeans.lib.awtextra.AbsoluteConstraints(1000, 550, 100, 30));

        btnRiwayat.setFont(new java.awt.Font("Segoe UI", 0, 12)); // NOI18N
        btnRiwayat.setText("Riwayat");
        btnRiwayat.setPreferredSize(new java.awt.Dimension(63, 23));
        btnRiwayat.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRiwayatActionPerformed(evt);
            }
        });
        panelPermintaanObat.add(btnRiwayat, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 630, 100, 40));

        simpan.setFont(new java.awt.Font("Segoe UI", 0, 12)); // NOI18N
        simpan.setText("Simpan");
        simpan.setPreferredSize(new java.awt.Dimension(63, 23));
        simpan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                simpanActionPerformed(evt);
            }
        });
        panelPermintaanObat.add(simpan, new org.netbeans.lib.awtextra.AbsoluteConstraints(1110, 550, 80, 30));

        combo.setFont(new java.awt.Font("SansSerif", 0, 18)); // NOI18N
        combo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "--Pilih Unit--", "RS. Jember Klinik", "RS. Baladhika Husada", "RS. Siloam Lippo", "RS. Paru - paru", "RS. Soebandi", "RS. Bina Sehat" }));
        combo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                comboActionPerformed(evt);
            }
        });
        panelPermintaanObat.add(combo, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 210, 280, 40));

        tabelDaftarObat.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tabelDaftarObat.setSelectionBackground(new java.awt.Color(255, 102, 0));
        jScrollPane1.setViewportView(tabelDaftarObat);

        panelPermintaanObat.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(740, 210, -1, 120));

        jPanel1.setBackground(new java.awt.Color(113, 53, 49));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        panelPermintaanObat.add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 90, 1220, 600));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(panelPermintaanObat, javax.swing.GroupLayout.PREFERRED_SIZE, 1292, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 23, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(panelPermintaanObat, javax.swing.GroupLayout.PREFERRED_SIZE, 699, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void menuLaporanMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_menuLaporanMouseClicked

//        MenuLaporanBulanan mm = new MenuLaporanBulanan();
//        mm.setVisible(true);
//        this.dispose();
    }//GEN-LAST:event_menuLaporanMouseClicked

    private void labelMenuPermintaanObatMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_labelMenuPermintaanObatMouseClicked
//        PermintaanObat zx = new PermintaanObat();
//        zx.setVisible(true);
//        this.dispose();
    }//GEN-LAST:event_labelMenuPermintaanObatMouseClicked

    private void menuStokMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_menuStokMouseClicked
        // TODO add your handling code here:
        try {
            model.navObat(this);
        } catch (Exception e) {
        }
    }//GEN-LAST:event_menuStokMouseClicked

    private void menuLogoutMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_menuLogoutMouseClicked
        
    }//GEN-LAST:event_menuLogoutMouseClicked

    private void menuLaporan1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_menuLaporan1MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_menuLaporan1MouseClicked

    private void labelMenuPermintaanObat1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_labelMenuPermintaanObat1MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_labelMenuPermintaanObat1MouseClicked

    private void menuStok1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_menuStok1MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_menuStok1MouseClicked

    private void menuLogout1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_menuLogout1MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_menuLogout1MouseClicked

    private void inputUmurActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inputUmurActionPerformed
        // TODO add your handling code here:

    }//GEN-LAST:event_inputUmurActionPerformed

    private void inputUmurKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_inputUmurKeyTyped
        // TODO add your handling code here:
        
    }//GEN-LAST:event_inputUmurKeyTyped

    private void JKLakiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JKLakiActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_JKLakiActionPerformed

    private void JKPerempuanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JKPerempuanActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_JKPerempuanActionPerformed

    private void inputDiagnosisActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inputDiagnosisActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_inputDiagnosisActionPerformed

    private void inputCariObatActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inputCariObatActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_inputCariObatActionPerformed

    private void buttonCariObatActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonCariObatActionPerformed
        // TODO add your handling code here:
        try {
            model.cariObatTBL(this);
            
        } catch (Exception e) {
        }
    }//GEN-LAST:event_buttonCariObatActionPerformed

    private void buttonTambahObatActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonTambahObatActionPerformed
        // TODO add your handling code here:
//        int spinner = (int) inputJumlah.getValue();
//        DefaultTableModel model = (DefaultTableModel)tabelDaftarObat.getModel();
//        int selectedRowIndex = tabelDaftarObat.getSelectedRow();
//
//        int itung = (spinner);
//
//        if (itung < 1) {
//            JOptionPane.showMessageDialog(null, "Jumlah tidak boleh NEGATIF ataupun KOSONG !!! ", "Peringatan", JOptionPane.WARNING_MESSAGE);
//        }
//        else{
//
//            mdl.addRow(new Object []{
//                (model.getValueAt(selectedRowIndex, 0).toString()),(model.getValueAt(selectedRowIndex, 1).toString()),
//                (model.getValueAt(selectedRowIndex, 2).toString()),(String.valueOf(itung))}) ;
//        tabelPilihObat.setModel(mdl) ;
//        x3 = new javax.swing.JTextField();
//        x3.setText((model.getValueAt(selectedRowIndex, 0).toString()));
//        x3.setVisible(false);
//        x4 = new javax.swing.JTextField();
//        x4.setText((model.getValueAt(selectedRowIndex, 1).toString()));
//        x4.setVisible(false);
//        x5 = new javax.swing.JTextField();
//        x5.setText((model.getValueAt(selectedRowIndex, 2).toString()));
//        x5.setVisible(false);
//        x6 = new javax.swing.JTextField();
//        x6.setText((String.valueOf(itung)));
//        x6.setVisible(false);
//        }
    }//GEN-LAST:event_buttonTambahObatActionPerformed

    private void hapusObatActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_hapusObatActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_hapusObatActionPerformed

    private void btnRiwayatActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRiwayatActionPerformed
        try {
            model.btnRiwayat(this);
        } catch (Exception e) {
        }
    }//GEN-LAST:event_btnRiwayatActionPerformed

    private void simpanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_simpanActionPerformed
        try {
            model.simpanPermintaanObat(this);
        } catch (Exception e) {
        }
//  
    }//GEN-LAST:event_simpanActionPerformed

    private void comboActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_comboActionPerformed
 
        
    }//GEN-LAST:event_comboActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(PermintaanObat.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(PermintaanObat.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(PermintaanObat.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(PermintaanObat.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new PermintaanObat().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    public javax.swing.JRadioButton JKLaki;
    public javax.swing.JRadioButton JKPerempuan;
    public javax.swing.JButton btnRiwayat;
    public javax.swing.JButton buttonCariObat;
    private javax.swing.ButtonGroup buttonGroup1;
    public javax.swing.JButton buttonTambahObat;
    public javax.swing.JComboBox<String> combo;
    public javax.swing.JButton hapusObat;
    private javax.swing.JLabel icon;
    private javax.swing.JLabel icon1;
    private javax.swing.JLabel iconLogout;
    private javax.swing.JLabel iconLogout1;
    public javax.swing.JTextArea inputAlamat;
    public javax.swing.JTextField inputCariObat;
    public javax.swing.JTextField inputDiagnosis;
    public javax.swing.JSpinner inputJumlah;
    public javax.swing.JTextField inputNamaKK;
    public javax.swing.JTextField inputNamaPasien;
    public javax.swing.JTextField inputPekerjaan;
    public javax.swing.JTextField inputUmur;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel labelAlamat;
    private javax.swing.JLabel labelCariObat;
    private javax.swing.JLabel labelDaftarObat;
    private javax.swing.JLabel labelDiagnosis;
    private javax.swing.JLabel labelJenisKelamin;
    private javax.swing.JLabel labelJumlah;
    private javax.swing.JLabel labelLogout;
    private javax.swing.JLabel labelLogout1;
    private javax.swing.JLabel labelMenuLaporan;
    private javax.swing.JLabel labelMenuLaporan1;
    private javax.swing.JLabel labelMenuPermintaanObat;
    private javax.swing.JLabel labelMenuPermintaanObat1;
    private javax.swing.JLabel labelMenuStok;
    private javax.swing.JLabel labelMenuStok1;
    private javax.swing.JLabel labelNamaKK;
    private javax.swing.JLabel labelNamaPasien;
    private javax.swing.JLabel labelPekerjaan;
    private javax.swing.JLabel labelPermintaanObat;
    private javax.swing.JLabel labelPilihObat;
    private javax.swing.JLabel labelUmur;
    private javax.swing.JLabel labelUnit;
    private javax.swing.JPanel menuBar;
    private javax.swing.JPanel menuBar1;
    public javax.swing.JPanel menuLaporan;
    private javax.swing.JPanel menuLaporan1;
    private javax.swing.JPanel menuLogout;
    private javax.swing.JPanel menuLogout1;
    public javax.swing.JPanel menuPermintaanObat;
    private javax.swing.JPanel menuPermintaanObat1;
    public javax.swing.JPanel menuStok;
    private javax.swing.JPanel menuStok1;
    private javax.swing.JScrollPane panelInputAlamat;
    public javax.swing.JPanel panelPermintaanObat;
    private javax.swing.JScrollPane panelTabelPilihObat;
    public javax.swing.JButton simpan;
    public javax.swing.JTable tabelDaftarObat;
    public javax.swing.JTable tabelPilihObat;
    private javax.swing.JLabel tanggalSekarang;
    // End of variables declaration//GEN-END:variables
}
