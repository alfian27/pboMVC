package com.view;

import java.util.ArrayList;
import java.util.List;
import javax.swing.JFrame;
import javax.swing.JOptionPane;


public class GantiPassword extends javax.swing.JFrame {

    public GantiPassword() {
        initComponents();
    }

 
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        panelLogin = new javax.swing.JPanel();
        password = new javax.swing.JPasswordField();
        buttonKembali = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        labelPasswordBaru = new javax.swing.JLabel();
        buttonLogin = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);

        panelLogin.setBackground(new java.awt.Color(255, 87, 87));
        panelLogin.setMinimumSize(new java.awt.Dimension(0, 0));
        panelLogin.setPreferredSize(new java.awt.Dimension(1280, 720));
        panelLogin.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        password.setToolTipText("insert Password");
        password.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                passwordActionPerformed(evt);
            }
        });
        panelLogin.add(password, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 340, 380, 30));

        buttonKembali.setText("KEMBALI");
        buttonKembali.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonKembaliActionPerformed(evt);
            }
        });
        panelLogin.add(buttonKembali, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 680, 90, 30));

        jPanel1.setBackground(new java.awt.Color(113, 53, 49));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        labelPasswordBaru.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        labelPasswordBaru.setForeground(new java.awt.Color(255, 255, 255));
        labelPasswordBaru.setText("MASUKKAN PASSWORD BARU");
        jPanel1.add(labelPasswordBaru, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 270, -1, -1));

        buttonLogin.setText("SUBMIT");
        buttonLogin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonLoginActionPerformed(evt);
            }
        });
        jPanel1.add(buttonLogin, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 300, 110, 30));

        panelLogin.add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 40, 560, 630));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(panelLogin, javax.swing.GroupLayout.PREFERRED_SIZE, 640, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(panelLogin, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void passwordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_passwordActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_passwordActionPerformed

    private void buttonLoginActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonLoginActionPerformed

    }//GEN-LAST:event_buttonLoginActionPerformed

    private void buttonKembaliActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonKembaliActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_buttonKembaliActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new FormLogin().setVisible(true);
            }
        });
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton buttonKembali;
    private javax.swing.JButton buttonLogin;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel labelPasswordBaru;
    private javax.swing.JPanel panelLogin;
    private javax.swing.JPasswordField password;
    // End of variables declaration//GEN-END:variables
}
